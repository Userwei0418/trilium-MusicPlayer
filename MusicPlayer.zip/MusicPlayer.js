/*
 * Simple Music Player Widget for Trilium Notes
 * Independent widget - similar structure to tomato timer
 */

const TPL = `
<audio id="musicPlayerAudio"></audio>

<div id="player-bar" class="player">
    <div id="track-info">
        <span id="track-name">No track</span>
    </div>
    <div id="progress-container">
        <input id="progressBar" type="range" min="0" max="100" value="0" style="width: 150px; height: 4px; cursor: pointer;">
        <span id="time-display" style="font-size: 11px; color: #aaa; margin-left: 6px; width: 40px;">0:00/0:00</span>
    </div>
    <div id="volume-container">
        <input id="volumeSlider" type="range" min="0" max="100" value="70" style="width: 60px; height: 4px; cursor: pointer;">
        <span id="volume-label" style="font-size: 10px; color: #aaa; margin-left: 4px;">70%</span>
    </div>
    <div id="player-controls">
        <button id="modeButton" title="播放模式">🔁 循环</button>
        <button id="prevButton">⏮ Prev</button>
        <button id="playPauseButton">▶ Play</button>
        <button id="nextButton">Next ⏭</button>
    </div>
</div>
`;

const styles = `
#player-bar {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 6px 12px;
    border-top: 1px solid #555555;
    border-bottom: 1px solid #555555;
    background: #1a1a1a;
    white-space: nowrap;
    height: 40px;
}

#track-info {
    flex: 0 0 120px;
    min-width: 0;
    display: flex;
    align-items: center;
}

#track-name {
    color: #ffffff;
    font-size: 13px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: block;
    line-height: 1;
}

#progress-container {
    display: flex;
    align-items: center;
    gap: 6px;
    flex: 1;
    min-width: 0;
}

#progressBar {
    flex: 1;
}

#progressBar::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #2196F3;
    cursor: pointer;
}

#progressBar::-moz-range-thumb {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #2196F3;
    cursor: pointer;
    border: none;
}

#time-display {
    flex: 0 0 50px;
}

#volume-container {
    display: flex;
    align-items: center;
    gap: 4px;
    flex: 0 0 auto;
}

#volumeSlider {
    flex: 0 0 60px;
}

#volumeSlider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #4CAF50;
    cursor: pointer;
}

#volumeSlider::-moz-range-thumb {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #4CAF50;
    cursor: pointer;
    border: none;
}

#volume-label {
    flex: 0 0 30px;
}

#player-controls {
    display: flex;
    gap: 6px;
    align-items: center;
    flex: 0 0 auto;
}

.player button {
    background-color: #2196F3;
    border-radius: 4px;
    border: none;
    padding: 5px 10px;
    font-size: 11px;
    cursor: pointer;
    transition: background-color 0.3s;
    color: #ffffff;
    white-space: nowrap;
    line-height: 1;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.player button:hover {
    background-color: #1e87db;
}

#modeButton {
    background-color: #FF9800;
}

#modeButton:hover {
    background-color: #F57C00;
}

#modeButton.active {
    background-color: #4CAF50;
}
`;

var isInit = true;
var currentTrackIndex = 0;
var isPlaying = false;
var musicList = [];
var audioElement = null;
var playMode = 'order'; // 'order'(顺序) 'single'(单曲循环) 'random'(随机)

class MusicPlayerWidget extends api.NoteContextAwareWidget {
    get position() { return 300; }
    get parentWidget() { return "center-pane"; }

    constructor() {
        super();
        this.title = "";
    }

    isEnabled() {
        if (!super.isEnabled()) return false;
        const widgetDisable = api.startNote.hasLabel("disable");
        const isHidden = localStorage.getItem('musicPlayerVisible') === 'false';
        return !widgetDisable && !isHidden;
    }

    doRender() {
        this.$widget = $(TPL);
        this.cssBlock(styles);
        
        // 检查初始隐藏状态
        const playerBar = this.$widget.find("#player-bar");
        const isHidden = localStorage.getItem('musicPlayerVisible') === 'false';
        if (isHidden) {
            playerBar.css('display', 'none');
        }
        
        // 在 refreshWithNote 中监听变化
        this.playerBar = playerBar;
        
        return this.$widget;
    }

    async refreshWithNote() {
        // prevent duplicate initialization
        if (!isInit) {
            return;
        }
        isInit = false;

        const playButton = document.getElementById('playPauseButton');
        const prevButton = document.getElementById('prevButton');
        const nextButton = document.getElementById('nextButton');
        const modeButton = document.getElementById('modeButton');
        const trackNameDisplay = document.getElementById('track-name');
        const playerBar = document.getElementById('player-bar');
        const progressBar = document.getElementById('progressBar');
        const volumeSlider = document.getElementById('volumeSlider');
        const timeDisplay = document.getElementById('time-display');
        const volumeLabel = document.getElementById('volume-label');
        
        // 获取音频元素（已在 TPL 中定义）
        audioElement = document.getElementById('musicPlayerAudio');

        // 获取音乐列表
        const loadMusicList = async () => {
            try {
                // 暂时用硬编码的列表作为示例
                // 根据你的实际文件路径修改这里
                musicList = [
                    { name: '指纹', src: 'custom/sound/指纹.mp3' },
                    { name: '绿光', src: 'custom/sound/绿光.mp3' },
                    { name: '洋葱', src: 'custom/sound/洋葱.mp3' },
                ];
                
                console.log('Music list loaded:', musicList);
                
                if (musicList.length > 0) {
                    updateTrackDisplay();
                } else {
                    trackNameDisplay.textContent = 'No music files';
                }
            } catch (error) {
                console.error('Failed to load music list:', error);
                trackNameDisplay.textContent = 'Error loading music';
            }
        };

        // 更新轨道显示
        const updateTrackDisplay = () => {
            if (musicList.length > 0) {
                const track = musicList[currentTrackIndex];
                trackNameDisplay.textContent = track.name;
                audioElement.src = track.src;
            }
        };

        // 播放/暂停
        const togglePlayPause = () => {
            if (musicList.length === 0) {
                api.showMessage('No music files found', 2000);
                return;
            }

            if (isPlaying) {
                audioElement.pause();
                playButton.textContent = '▶ Play';
                isPlaying = false;
            } else {
                audioElement.play();
                playButton.textContent = '⏸ Pause';
                isPlaying = true;
            }
            localStorage.setItem('musicPlayerState', isPlaying);
        };

        // 下一首
        const playNext = () => {
            if (musicList.length === 0) return;
            
            if (playMode === 'single') {
                // 单曲循环
                audioElement.currentTime = 0;
                audioElement.play();
            } else if (playMode === 'random') {
                // 随机播放
                currentTrackIndex = Math.floor(Math.random() * musicList.length);
                updateTrackDisplay();
                audioElement.play();
            } else {
                // 顺序播放
                currentTrackIndex = (currentTrackIndex + 1) % musicList.length;
                updateTrackDisplay();
                audioElement.play();
            }
            
            playButton.textContent = '⏸ Pause';
            isPlaying = true;
            localStorage.setItem('currentMusicTrack', currentTrackIndex);
        };

        // 上一首
        const playPrev = () => {
            if (musicList.length === 0) return;
            currentTrackIndex = (currentTrackIndex - 1 + musicList.length) % musicList.length;
            updateTrackDisplay();
            audioElement.play();
            playButton.textContent = '⏸ Pause';
            isPlaying = true;
            localStorage.setItem('currentMusicTrack', currentTrackIndex);
        };

        // 格式化时间显示
        const formatTime = (seconds) => {
            if (isNaN(seconds)) return '0:00';
            const mins = Math.floor(seconds / 60);
            const secs = Math.floor(seconds % 60);
            return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
        };

        // 更新进度条
        audioElement.addEventListener('timeupdate', () => {
            if (audioElement.duration) {
                const percent = (audioElement.currentTime / audioElement.duration) * 100;
                progressBar.value = percent;
                timeDisplay.textContent = `${formatTime(audioElement.currentTime)}/${formatTime(audioElement.duration)}`;
            }
        });

        // 点击进度条跳转
        progressBar.addEventListener('input', (e) => {
            if (audioElement.duration) {
                audioElement.currentTime = (e.target.value / 100) * audioElement.duration;
            }
        });

        // 音量控制
        volumeSlider.addEventListener('input', (e) => {
            const volume = e.target.value / 100;
            audioElement.volume = volume;
            volumeLabel.textContent = `${e.target.value}%`;
            localStorage.setItem('musicPlayerVolume', e.target.value);
        });

        // 恢复之前保存的音量
        const savedVolume = localStorage.getItem('musicPlayerVolume') || 70;
        volumeSlider.value = savedVolume;
        audioElement.volume = savedVolume / 100;
        volumeLabel.textContent = `${savedVolume}%`;

        // 切换播放模式
        const togglePlayMode = () => {
            if (playMode === 'order') {
                playMode = 'single';
                modeButton.textContent = '🔂 单曲';
                modeButton.classList.add('active');
            } else if (playMode === 'single') {
                playMode = 'random';
                modeButton.textContent = '🔀 随机';
                modeButton.classList.add('active');
            } else {
                playMode = 'order';
                modeButton.textContent = '🔁 循环';
                modeButton.classList.remove('active');
            }
            localStorage.setItem('musicPlayerMode', playMode);
        };

        // 恢复之前保存的播放模式
        const savedMode = localStorage.getItem('musicPlayerMode') || 'order';
        playMode = savedMode;
        if (playMode === 'order') {
            modeButton.textContent = '🔁 循环';
            modeButton.classList.remove('active');
        } else if (playMode === 'single') {
            modeButton.textContent = '🔂 单曲';
            modeButton.classList.add('active');
        } else {
            modeButton.textContent = '🔀 随机';
            modeButton.classList.add('active');
        }

        // 监听 localStorage 变化以实现显示/隐藏
        window.addEventListener('storage', (e) => {
            if (e.key === 'musicPlayerVisible') {
                const isHidden = e.newValue === 'false';
                if (isHidden) {
                    playerBar.style.display = 'none';
                } else {
                    playerBar.style.display = 'flex';
                }
            }
        });

        // 定时检查 localStorage 变化（处理同一标签页的情况）
        let lastVisibilityState = localStorage.getItem('musicPlayerVisible');
        setInterval(() => {
            const currentState = localStorage.getItem('musicPlayerVisible');
            if (currentState !== lastVisibilityState) {
                lastVisibilityState = currentState;
                const isHidden = currentState === 'false';
                if (isHidden) {
                    playerBar.style.display = 'none';
                } else {
                    playerBar.style.display = 'flex';
                }
            }
        }, 100);

        // 歌曲结束自动下一首
        audioElement.addEventListener('ended', playNext);

        // 绑定按钮事件
        playButton.addEventListener('click', togglePlayPause);
        nextButton.addEventListener('click', playNext);
        prevButton.addEventListener('click', playPrev);
        modeButton.addEventListener('click', togglePlayMode);

        // 加载初始状态
        await loadMusicList();
        
        // 恢复之前的状态
        const savedTrack = localStorage.getItem('currentMusicTrack');
        if (savedTrack) {
            currentTrackIndex = parseInt(savedTrack);
            updateTrackDisplay();
        }
    }

    async entitiesReloadedEvent({ loadResults }) {
        
    }
}

module.exports = new MusicPlayerWidget();