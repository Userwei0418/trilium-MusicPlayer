// 音乐播放器显示/隐藏控制脚本
// 用于左侧 launcher 按钮

async function toggleMusicPlayer() {
    const isHidden = localStorage.getItem('musicPlayerVisible') === 'false';
    
    if (isHidden) {
        localStorage.setItem('musicPlayerVisible', 'true');
        api.showMessage('🎵 Music Player Shown', 2000);
    } else {
        localStorage.setItem('musicPlayerVisible', 'false');
        api.showMessage('🎵 Music Player Hidden', 2000);
    }
    
    // 立即刷新前端
    api.triggerCommand('reloadFrontend');
}

await toggleMusicPlayer();