api.createOrUpdateLauncher({
       id: 'MusicPlayer',
       type: 'script',
       title: 'Show/Hide Music Player',
       icon: 'bx-music',
       keyboardShortcut: 'alt+m',
       scriptNoteId: api.currentNote.getRelationValue('ToggleMusicPlayer'),
       isVisible: true
   });